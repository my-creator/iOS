//
//  likePost.swift
//  crecreProject
//
//  Created by 하준혁 on 2019. 7. 2..
//  Copyright © 2019년 하준혁. All rights reserved.
//

import Foundation


struct likePost {
    var postTitle: String
    
    init(title: String){
        self.postTitle = title
    }
}
