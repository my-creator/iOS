//
//  PostCell.swift
//  crecreProject
//
//  Created by 하준혁 on 2019. 7. 2..
//  Copyright © 2019년 하준혁. All rights reserved.
//

import UIKit

class PostCell: UITableViewCell {
    
    @IBOutlet var postTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
